var R=require("../../chunks/[turbopack]_runtime.js")("server/app/favicon.ico/route.js")
R.c("server/chunks/[root-of-the-server]__e39d21ef._.js")
R.c("server/chunks/ed3a5_next_dist_esm_build_templates_app-route_baf8f07d.js")
R.c("server/chunks/ed3a5_next_dist_fb10e2b3._.js")
R.c("server/chunks/ed3a5_next_dist_f1931ab8._.js")
R.c("server/chunks/[root-of-the-server]__0dee7300._.js")
R.m(44598)
R.m(11299)
module.exports=R.m(11299).exports
