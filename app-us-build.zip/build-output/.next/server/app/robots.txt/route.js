var R=require("../../chunks/[turbopack]_runtime.js")("server/app/robots.txt/route.js")
R.c("server/chunks/[root-of-the-server]__1b6b05ac._.js")
R.c("server/chunks/ed3a5_next_dist_fb10e2b3._.js")
R.c("server/chunks/ed3a5_next_dist_f1931ab8._.js")
R.c("server/chunks/[root-of-the-server]__0dee7300._.js")
R.m(50912)
R.m(49761)
module.exports=R.m(49761).exports
