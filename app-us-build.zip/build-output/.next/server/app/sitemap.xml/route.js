var R=require("../../chunks/[turbopack]_runtime.js")("server/app/sitemap.xml/route.js")
R.c("server/chunks/[root-of-the-server]__b29428b4._.js")
R.c("server/chunks/ed3a5_next_dist_fb10e2b3._.js")
R.c("server/chunks/ed3a5_next_dist_f1931ab8._.js")
R.c("server/chunks/[root-of-the-server]__0dee7300._.js")
R.m(14211)
R.m(55505)
module.exports=R.m(55505).exports
