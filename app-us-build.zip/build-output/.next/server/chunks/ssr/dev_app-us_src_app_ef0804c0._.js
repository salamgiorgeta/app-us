module.exports=[44179,a=>{a.v("/_next/static/media/favicon.0b3bf435.ico")},27634,a=>{"use strict";a.s(["default",()=>b]);let b={src:a.i(44179).default,width:256,height:256}}];

//# sourceMappingURL=dev_app-us_src_app_ef0804c0._.js.map