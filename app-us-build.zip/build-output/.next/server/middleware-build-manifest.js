globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": [
      "static/chunks/bccb680516926602.js",
      "static/chunks/9c3014f10e37b80c.js",
      "static/chunks/turbopack-399e257ecbecd7dc.js"
    ],
    "/_error": [
      "static/chunks/93fb8498006d987a.js",
      "static/chunks/9c3014f10e37b80c.js",
      "static/chunks/turbopack-8236f4c3edd6ebc2.js"
    ]
  },
  "devFiles": [],
  "ampDevFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/44e6bc59b194b58c.js",
    "static/chunks/598a814bce6bd39a.js",
    "static/chunks/54178c327ca895be.js",
    "static/chunks/960cca40fb6af6da.js",
    "static/chunks/turbopack-79dd24f2aa197757.js"
  ],
  "ampFirstPages": []
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
,"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js",

];