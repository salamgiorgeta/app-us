var R=require("../chunks/ssr/[turbopack]_runtime.js")("server/pages/_app.js")
R.c("server/chunks/ssr/[root-of-the-server]__7c747043._.js")
R.m(49554)
module.exports=R.m(49554).exports
