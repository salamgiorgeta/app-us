var R=require("../chunks/ssr/[turbopack]_runtime.js")("server/pages/_document.js")
R.c("server/chunks/ssr/[root-of-the-server]__3a9762bf._.js")
R.c("server/chunks/ssr/[root-of-the-server]__577908fa._.js")
R.m(46289)
module.exports=R.m(46289).exports
