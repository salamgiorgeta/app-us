__turbopack_load_page_chunks__("/_app", [
  "static/chunks/bccb680516926602.js",
  "static/chunks/9c3014f10e37b80c.js",
  "static/chunks/turbopack-399e257ecbecd7dc.js"
])
