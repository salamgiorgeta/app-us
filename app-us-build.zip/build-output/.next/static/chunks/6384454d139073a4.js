__turbopack_load_page_chunks__("/_error", [
  "static/chunks/93fb8498006d987a.js",
  "static/chunks/9c3014f10e37b80c.js",
  "static/chunks/turbopack-8236f4c3edd6ebc2.js"
])
